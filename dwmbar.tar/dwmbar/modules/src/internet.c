#include <stdio.h>

int main()
{
    char *internet_icon = " ";

    printf("%s\n", internet_icon);

    return 0;
}
