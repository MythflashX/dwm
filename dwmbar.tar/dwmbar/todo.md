# TODO

- Separator optional between modules
- Call all modules once on startup, then deal with delays
- Different archupdates and arch AUR updates that write to the same file so you can use only 1 of them
